package com.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.service.TransactionService;
@CrossOrigin(origins="http://localhost:4500")
@RestController
public class TransactionController {
	@Autowired
	TransactionService service;
	
	
	@GetMapping(value="/merchant/transactions")
	public List allTransactions()
	{
		return service.getAllTransactions();
	}
}
