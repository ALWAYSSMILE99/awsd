package com.capstore.service;

import java.util.List;

import com.capstore.model.Transaction;

public interface TransactionService {

	public List<Transaction> getAllTransactions();
}
