package com.capstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstore.model.Transaction;
import com.capstore.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {


	@Autowired
	TransactionRepository transactionRepository ;
	
	
	@Override
	public List<Transaction> getAllTransactions() {
		

		return transactionRepository.findAll(); 
		
		
		
	}

}
