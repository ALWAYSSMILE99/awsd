package com.capstore.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Transaction")
public class Transaction {
	@Id
	@Column(name = "transactionid")
	long transactionId;
	@Column(name = "productid")
	long productId;
	@Column(name = "amount")
	double amount;
	@Column(name = "statusofpayment")
	String statusOfPayment;
	@Column(name = "modeofpayment")
	String modeOfPayment;
	@Column(name = "dop")
	Date dop;
	@Column(name = "customerid")
	long customerId;

	public long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(long transactionId) {
		this.transactionId = transactionId;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getStatusOfPayment() {
		return statusOfPayment;
	}

	public void setStatusOfPayment(String statusOfPayment) {
		this.statusOfPayment = statusOfPayment;
	}

	public String getModeOfPayment() {
		return modeOfPayment;
	}

	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}

	public Date getDop() {
		return dop;
	}

	public void setDop(Date dop) {
		this.dop = dop;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

}
